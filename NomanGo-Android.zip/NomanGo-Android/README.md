# NOMAN GO – native Android browser (v3.0)

A small, fast browser built on Android `WebView`. The home page, Settings, History,
Bookmarks and Downloads screens are one HTML file (`app/src/main/assets/index.html`)
shown inside the native app. Everything else (toolbar, tabs, menu, downloads, voice search)
is native Kotlin, so scrolling and animations stay on the GPU.

## Toolbar (same order as Chrome)

`Home` | `URL / search pill` | `Mic` | `Tabs (live count)` | `Three-dot menu`

* **Home** loads the NOMAN GO home page. If you are already there it scrolls to the top.
* **URL pill** shows a green lock (https), an orange info icon (http) or a search icon. While a
  page loads the icon spins and the pill gets an accent border, next to the progress bar.
* **Mic** opens the system voice search (no extra permission needed). It is hidden automatically
  on phones without a speech recogniser, and can be switched off in Settings > Search.
* **Tabs** opens the tab switcher. The number bounces when it changes.
* **Menu** icon row: Back, Forward, Bookmark (web pages), Refresh / Stop.
  List: New tab, New incognito tab, Share (web pages), **Desktop site**, Bookmarks, History,
  Downloads, Settings. Every icon pops in, then loops a small animation while the menu is open.

## Desktop site: always in the menu

* On a **web page**: switches that site between mobile and desktop. The WebView user agent is set
  before the page loads, the viewport is widened and the page reloads. It is remembered per site and
  listed in Settings > Desktop site, where each site can be removed.
* On the **home page and internal pages**: the same row reads "Desktop site (all sites)" and
  toggles the global setting. The home page switches to its desktop layout straight away and every
  site without its own choice follows it.
* A site-specific choice always wins over the global one.

## Build the APK without Android Studio

1. Create a GitHub repository and upload the **contents** of this folder to its root.
2. Open the *Actions* tab, choose **Build debug APK**, press **Run workflow**.
3. When it finishes, download the artifact `NomanGo-debug-apk` and install `app-debug.apk`.

Or open the folder in Android Studio (Hedgehog or newer, JDK 17) and press Run.

## Smoothness notes

* No bottom bar, no software layers, no alpha fades on the WebView itself.
* Theme colours are only re-applied when they actually change.
* Toolbar and menu animations use property animators (translation, scale, rotation, alpha) only.
* Background tabs are paused and hidden. Menu icon loops are cancelled when the menu closes.
* Settings > Performance > "Reduced animations" or "Battery saver" turns all of the above off.

## Known limits

* Incognito tabs have no separate cookie jar (WebView limitation), but history is not saved.
* The `Sec-CH-UA-Mobile` client hint is not changed. Sites that detect desktop only through it
  may still serve the mobile page. The user agent and viewport are changed, which is what
  almost every site uses.
* No find-in-page, tab thumbnails, autofill or sync yet.
* This project was written and statically checked, but the Kotlin code has not been compiled on
  a device in this session. The first GitHub Actions build is the real test.
