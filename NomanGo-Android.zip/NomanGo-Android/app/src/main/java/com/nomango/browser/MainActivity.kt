package com.nomango.browser

import android.Manifest
import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.res.ColorStateList
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

private class Pal(
    val bar: Int, val pill: Int, val text: Int, val sub: Int,
    val accent: Int, val bg: Int, val card: Int, val line: Int, val dark: Boolean
)

private class Eng(val web: String, val img: String, val safe: String)

/**
 * NOMAN GO browser shell.
 *
 *  - native top toolbar: Back, Forward, Refresh, URL/Search bar, three-dot menu
 *  - one WebView per tab (normal or incognito-style), desktop/mobile mode per tab
 *  - the home page, History, Bookmarks, Downloads and Settings screens are the bundled
 *    assets/index.html, talking to this class through the "NomanNative" JavaScript bridge
 */
class MainActivity : Activity() {

    companion object {
        private const val HOME = "file:///android_asset/index.html"
        private const val ASSET = "file:///android_asset/"
        private const val REQ_FILE = 11
        private const val REQ_STORAGE = 12
        private const val REQ_VOICE = 13
        private val STAR: Int = 0xFFF5A524.toInt()
        private val ACC_LIGHT = arrayOf("#E5192B", "#2B6BFF", "#10B981", "#F97316", "#6366F1")
        private val ACC_DARK = arrayOf("#FF2D3F", "#4D86FF", "#34D399", "#FB923C", "#818CF8")
        private val SCOPES = arrayOf("Images", "YouTube", "Wikipedia", "GitHub", "Maps", "Shopping")
        private val URL_RE = Regex(
            "^(https?://)?(([\\w-]+\\.)+[a-z]{2,}|localhost|\\d{1,3}(\\.\\d{1,3}){3})(:\\d+)?(/\\S*)?$",
            RegexOption.IGNORE_CASE
        )
        private const val DESKTOP_JS =
            "(function(){var m=document.querySelector('meta[name=viewport]');" +
                "if(!m){m=document.createElement('meta');m.name='viewport';" +
                "(document.head||document.documentElement).appendChild(m);}" +
                "m.setAttribute('content','width=980');})();"
    }

    private val ENGINES = mapOf(
        "google" to Eng("https://www.google.com/search?q=", "https://www.google.com/search?tbm=isch&q=", "&safe=active"),
        "bing" to Eng("https://www.bing.com/search?q=", "https://www.bing.com/images/search?q=", "&adlt=strict"),
        "ddg" to Eng("https://duckduckgo.com/?q=", "https://duckduckgo.com/?iax=images&ia=images&q=", "&kp=1"),
        "yahoo" to Eng("https://search.yahoo.com/search?p=", "https://images.search.yahoo.com/search/images?p=", "&vm=r"),
        "brave" to Eng("https://search.brave.com/search?q=", "https://search.brave.com/images?q=", "&safesearch=strict")
    )

    private inner class Tab(val incognito: Boolean) {
        val web: WebView = WebView(this@MainActivity)
        var title: String = ""
        var url: String = ""
        var desktop: Boolean = false
        var trusted: Boolean = false
        var loading: Boolean = false
        var progress: Int = 0
        var parent: Tab? = null
        var errorPending: Boolean = false
        var errorShown: Boolean = false
        var manualHost: String? = null
    }

    // ---------- views ----------
    private lateinit var main: LinearLayout
    private lateinit var toolbar: LinearLayout
    private lateinit var btnHome: ImageButton
    private lateinit var btnMic: ImageButton
    private lateinit var urlPill: LinearLayout
    private lateinit var urlIcon: ImageView
    private lateinit var urlInput: EditText
    private lateinit var btnClear: ImageButton
    private lateinit var btnMenu: ImageButton
    private lateinit var btnTabs: FrameLayout
    private lateinit var tabCount: TextView
    private lateinit var progress: View
    private lateinit var content: FrameLayout
    private lateinit var suggestPanel: ScrollView
    private lateinit var suggestList: LinearLayout
    private lateinit var tabsOverlay: FrameLayout
    private lateinit var tabsTitle: TextView
    private lateinit var btnNewTab: TextView
    private lateinit var btnNewInc: TextView
    private lateinit var tabsList: LinearLayout
    private lateinit var toastView: TextView

    // ---------- state ----------
    private lateinit var store: Store
    private var st: JSONObject = JSONObject()
    private val tabs = ArrayList<Tab>()
    private var current: Tab? = null
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var uaMobile: String
    private lateinit var uaDesktop: String
    private val pillBg = GradientDrawable()
    private val tabBg = GradientDrawable()
    private var tabsOpen = false
    private var lastCount = 0
    private var lastRate = 0f
    private var lastPalKey = ""
    private var spinAnim: ObjectAnimator? = null
    private val menuAnims = ArrayList<Animator>()
    private var barColor = 0
    private var iconRes = 0
    private var settingText = false
    private var lastLoading = false
    private var animRows = true
    private var rowIdx = 0
    private var remoteHolder: LinearLayout? = null
    private var sugToken = 0
    private var sugRunnable: Runnable? = null
    private var menuPopup: PopupWindow? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var pendingDl: Array<String>? = null

    private val toastHide = Runnable {
        toastView.animate().alpha(0f).translationY(dpf(12f)).setDuration(d(200)).start()
    }

    // =====================================================================
    // lifecycle
    // =====================================================================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)
        st = store.settings()

        main = findViewById(R.id.main)
        toolbar = findViewById(R.id.toolbar)
        btnHome = findViewById(R.id.btnHome)
        btnMic = findViewById(R.id.btnMic)
        urlPill = findViewById(R.id.urlPill)
        urlIcon = findViewById(R.id.urlIcon)
        urlInput = findViewById(R.id.urlInput)
        btnClear = findViewById(R.id.btnClear)
        btnMenu = findViewById(R.id.btnMenu)
        btnTabs = findViewById(R.id.btnTabs)
        tabCount = findViewById(R.id.tabCount)
        progress = findViewById(R.id.progress)
        content = findViewById(R.id.content)
        suggestPanel = findViewById(R.id.suggestPanel)
        suggestList = findViewById(R.id.suggestList)
        tabsOverlay = findViewById(R.id.tabsOverlay)
        tabsTitle = findViewById(R.id.tabsTitle)
        btnNewTab = findViewById(R.id.btnNewTab)
        btnNewInc = findViewById(R.id.btnNewInc)
        tabsList = findViewById(R.id.tabsList)
        toastView = findViewById(R.id.toast)

        val def = WebSettings.getDefaultUserAgent(this)
        uaMobile = def.replace("; wv", "")
        val ver = Regex("Chrome/([\\d.]+)").find(def)?.groupValues?.get(1) ?: "120.0.0.0"
        uaDesktop = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$ver Safari/537.36"

        progress.pivotX = 0f
        progress.scaleX = 0f
        pillBg.cornerRadius = dpf(20f)
        tabBg.cornerRadius = dpf(8f)
        CookieManager.getInstance().setAcceptCookie(true)
        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        setupToolbar()
        setupTabsOverlay()
        applyTheme(false)
        applySettings()
        startSession(intent)
        applyBrandFont()
        playToolbarIntro()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        val u = intent?.data?.toString()
        if (u != null) newTab(u)
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
        stopIdle()
        current?.web?.onPause()
    }

    override fun onResume() {
        super.onResume()
        current?.web?.onResume()
        startIdle()
    }

    override fun onDestroy() {
        for (t in tabs) {
            (t.web.parent as? ViewGroup)?.removeView(t.web)
            t.web.destroy()
        }
        tabs.clear()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyTheme(true)
    }

    private fun startSession(i: Intent?) {
        val data = i?.data?.toString()
        if (stB("clrx", false)) store.clearHistory()
        val startMode = stS("start", "ntp")
        val url: String? = when {
            data != null -> data
            startMode == "last" -> store.get(Store.K_LAST)
            startMode == "page" -> stS("startUrl", "").let { if (it.isBlank()) null else resolve(it) }
            else -> null
        }
        newTab(url, stB("incs", false) && data == null)
    }

    // =====================================================================
    // helpers
    // =====================================================================
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpf(v: Float): Float = v * resources.displayMetrics.density
    private fun c(hex: String): Int = Color.parseColor(hex)
    private fun stS(k: String, d: String): String = st.optString(k, d)
    private fun stB(k: String, d: Boolean): Boolean = st.optBoolean(k, d)
    private fun stI(k: String, d: Int): Int = st.optInt(k, d)

    /** animation duration; 0 when the user chose reduced animations / battery saver */
    private fun d(ms: Long): Long = if (stS("anim", "full") == "reduced" || stB("eco", false)) 0L else ms

    private fun zoomPct(): Int = ((stS("zoom", "1").toFloatOrNull() ?: 1f) * 100f).toInt().coerceIn(50, 200)

    private fun rounded(fill: Int, radiusDp: Float, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dpf(radiusDp)
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
        return g
    }

    private fun circle(fill: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(fill)
        return g
    }

    private fun ripple(v: View) {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        v.setBackgroundResource(tv.resourceId)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(urlInput.windowToken, 0)
    }

    private fun dropFocus() {
        urlInput.clearFocus()
        main.requestFocus()
        hideKeyboard()
    }

    private fun esc(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun displayUrl(url: String): String {
        val q = searchQueryOf(url)
        if (q != null) return q
        val u = Uri.parse(url)
        return u.host?.removePrefix("www.") ?: url
    }

    /** The searched text when [url] is a results page of a known search engine, else null. */
    private fun searchQueryOf(url: String): String? {
        val u = Uri.parse(url)
        val h = (u.host ?: return null).removePrefix("www.")
        val path = u.path ?: ""
        val isSearch = (h.startsWith("google.") && path == "/search") ||
            (h.endsWith("bing.com") && path.startsWith("/search")) ||
            h == "duckduckgo.com" || h == "search.brave.com" || h == "search.yahoo.com"
        if (!isSearch) return null
        val q = u.getQueryParameter("q") ?: u.getQueryParameter("p")
        return if (q.isNullOrBlank()) null else q
    }

    private fun tabColor(s: String): Int {
        val cols = arrayOf("#4F8BFF", "#FF3B4E", "#16A56A", "#8B5CF6", "#F5A524", "#E84FA0", "#0FB5A5")
        var h = 0
        for (ch in s) h = (h * 31 + ch.code) and 0x7fffffff
        return c(cols[h % cols.size])
    }

    private fun showToast(msg: String) {
        toastView.text = msg
        ui.removeCallbacks(toastHide)
        toastView.animate().cancel()
        toastView.translationY = dpf(14f)
        toastView.animate().alpha(1f).translationY(0f).setDuration(d(220))
            .setInterpolator(OvershootInterpolator(1.6f)).start()
        ui.postDelayed(toastHide, 1900L)
    }

    // =====================================================================
    // settings + theme
    // =====================================================================
    private fun applySettings() {
        st = store.settings()
        val z = zoomPct()
        for (t in tabs) t.web.settings.textZoom = if (t.trusted) 100 else z
        for (t in tabs) {
            if (!t.trusted && t !== current) {
                val want = modeFor(t, hostOf(t.url))
                if (want != t.desktop) {
                    t.desktop = want
                    applyMode(t)
                }
            }
        }
        if (stB("wake", false)) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        applyMic()
        applyRefreshRate()
        applyTheme(true)
    }

    private fun pal(): Pal {
        val inc = current?.incognito == true
        val th = stS("theme", "system")
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val dark = inc || th == "dark" || (th == "system" && night)
        val a = stI("acc", 0).coerceIn(0, 4)
        return when {
            inc -> Pal(c("#150F2B"), c("#241B45"), c("#F1ECFF"), c("#A69BD0"), c("#9A73FF"), c("#0B0816"), c("#1B1336"), c("#2E2352"), true)
            dark -> Pal(c("#101015"), c("#1D1D26"), c("#F5F5FA"), c("#9A9AAE"), c(ACC_DARK[a]), c("#050507"), c("#17171F"), c("#26262F"), true)
            else -> Pal(c("#FFFFFF"), c("#EEF0F6"), c("#0D0D14"), c("#6F6F82"), c(ACC_LIGHT[a]), c("#F6F6F9"), c("#FFFFFF"), c("#E3E5EE"), false)
        }
    }

    private fun setBars(color: Int) {
        toolbar.setBackgroundColor(color)
        window.statusBarColor = color
        window.navigationBarColor = color
    }

    @Suppress("DEPRECATION")
    private fun setLightBars(light: Boolean) {
        var f = window.decorView.systemUiVisibility
        f = if (light) f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        if (Build.VERSION.SDK_INT >= 26) {
            f = if (light) f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            else f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        }
        window.decorView.systemUiVisibility = f
    }

    private fun applyTheme(animate: Boolean) {
        val p = pal()
        val key = "" + p.bar + "|" + p.pill + "|" + p.text + "|" + p.accent + "|" + p.bg
        if (key == lastPalKey) return
        lastPalKey = key
        val from = if (barColor == 0) p.bar else barColor
        barColor = p.bar
        window.statusBarColor = p.bar
        window.navigationBarColor = p.bar
        if (animate && from != p.bar && d(1L) > 0L) {
            val va = ValueAnimator.ofArgb(from, p.bar)
            va.duration = d(260)
            va.addUpdateListener { toolbar.setBackgroundColor(it.animatedValue as Int) }
            va.start()
        } else {
            toolbar.setBackgroundColor(p.bar)
        }
        setLightBars(!p.dark)
        window.setBackgroundDrawable(ColorDrawable(p.bg))
        btnHome.setColorFilter(c("#4F8BFF"), PorterDuff.Mode.SRC_IN)
        btnMic.setColorFilter(c("#8B5CF6"), PorterDuff.Mode.SRC_IN)
        btnMenu.setColorFilter(c("#FF7A2F"), PorterDuff.Mode.SRC_IN)
        btnClear.setColorFilter(p.sub, PorterDuff.Mode.SRC_IN)
        pillBg.setColor(if (p.dark) p.bg else p.pill)
        urlPill.background = pillBg
        urlInput.setTextColor(p.text)
        urlInput.setHintTextColor(p.sub)
        progress.setBackgroundColor(p.accent)
        suggestPanel.setBackgroundColor(p.bar)
        tabsOverlay.setBackgroundColor(p.bg)
        tabsTitle.setTextColor(p.text)
        btnNewTab.background = rounded(p.accent, 18f)
        btnNewTab.setTextColor(Color.WHITE)
        btnNewInc.background = rounded(p.pill, 18f)
        btnNewInc.setTextColor(p.text)
        toastView.background = rounded(if (p.dark) c("#F5F5FA") else c("#0D0D14"), 22f)
        toastView.setTextColor(if (p.dark) c("#0D0D14") else c("#F5F5FA"))
        for (t in tabs) t.web.setBackgroundColor(p.bg)
        refreshTabsButton()
        refreshUrlStroke()
        updateUrlUi()
    }

    private fun refreshUrlStroke() {
        val pp = pal()
        if (urlInput.hasFocus() || lastLoading) pillBg.setStroke(dp(2), pp.accent) else pillBg.setStroke(dp(1), pp.line)
    }

    // =====================================================================
    // toolbar
    // =====================================================================
    @SuppressLint("ClickableViewAccessibility")
    private fun press(v: View) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.82f).scaleY(0.82f).setDuration(d(90)).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(d(240))
                        .setInterpolator(OvershootInterpolator(2.5f)).start()
            }
            false
        }
    }

    private fun setupToolbar() {
        for (v in arrayOf<View>(btnHome, btnMic, btnTabs, btnMenu, btnClear)) press(v)

        btnHome.setOnClickListener { goHome() }
        btnMic.setOnClickListener { startVoice() }
        btnMenu.setOnClickListener { showMenu() }
        btnTabs.setOnClickListener { toggleTabs() }
        btnClear.setOnClickListener {
            urlInput.setText("")
            urlInput.requestFocus()
        }

        urlInput.setOnFocusChangeListener { _, focus -> onUrlFocus(focus) }
        urlInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!settingText) onUrlText(s?.toString() ?: "")
            }
        })
        urlInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                submitUrl()
                true
            } else {
                false
            }
        }
    }

    private fun setTextSilently(s: String) {
        settingText = true
        urlInput.setText(s)
        settingText = false
        btnClear.visibility = if (urlInput.hasFocus() && s.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun updateUrlUi() {
        val t = current ?: return
        val p = pal()
        if (!urlInput.hasFocus()) {
            setTextSilently(if (t.trusted || t.url.isEmpty()) "" else displayUrl(t.url))
        }
        if (lastLoading && !t.trusted) return
        val res: Int
        val tint: Int
        when {
            t.trusted || t.url.isEmpty() -> { res = R.drawable.ic_search; tint = p.sub }
            searchQueryOf(t.url) != null -> { res = R.drawable.ic_search; tint = p.accent }
            t.url.startsWith("https://") -> { res = R.drawable.ic_lock; tint = c("#16A56A") }
            else -> { res = R.drawable.ic_info; tint = c("#F59E0B") }
        }
        if (iconRes != res) {
            iconRes = res
            urlIcon.setImageResource(res)
            urlIcon.scaleX = 0.5f
            urlIcon.scaleY = 0.5f
            urlIcon.animate().scaleX(1f).scaleY(1f).setDuration(d(240))
                .setInterpolator(OvershootInterpolator(2f)).start()
        }
        urlIcon.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
    }

    private fun onUrlFocus(focus: Boolean) {
        refreshUrlStroke()
        urlPill.animate().scaleY(if (focus) 1.06f else 1f).setDuration(d(160)).start()
        if (focus) {
            val t = current
            setTextSilently(if (t == null || t.trusted) "" else t.url)
            urlInput.post { urlInput.selectAll() }
            animRows = true
            showSuggestPanel()
            buildSuggestions(urlInput.text.toString())
            animRows = false
            fetchRemote(urlInput.text.toString())
        } else {
            hideSuggestPanel()
            btnClear.visibility = View.GONE
            updateUrlUi()
        }
    }

    private fun onUrlText(q: String) {
        btnClear.visibility = if (urlInput.hasFocus() && q.isNotEmpty()) View.VISIBLE else View.GONE
        if (!urlInput.hasFocus()) return
        animRows = false
        buildSuggestions(q)
        fetchRemote(q)
    }

    private fun submitUrl() {
        val txt = urlInput.text.toString().trim()
        if (txt.isEmpty()) return
        dropFocus()
        navigateCurrent(txt)
    }

    private fun setLoading(b: Boolean) {
        if (b == lastLoading) return
        lastLoading = b
        spinAnim?.cancel()
        spinAnim = null
        urlIcon.rotation = 0f
        if (b) {
            iconRes = R.drawable.ic_refresh
            urlIcon.setImageResource(R.drawable.ic_refresh)
            urlIcon.setColorFilter(pal().accent, PorterDuff.Mode.SRC_IN)
            if (d(1L) > 0L) {
                val a = ObjectAnimator.ofFloat(urlIcon, View.ROTATION, 0f, 360f)
                a.duration = 900L
                a.interpolator = LinearInterpolator()
                a.repeatCount = ValueAnimator.INFINITE
                a.start()
                spinAnim = a
            }
        } else {
            iconRes = 0
        }
        refreshUrlStroke()
        if (!b) updateUrlUi()
    }

    private fun setProgress(p: Int) {
        progress.animate().cancel()
        if (p in 1..99) {
            progress.alpha = 1f
            progress.animate().scaleX(p / 100f).setDuration(d(220)).setInterpolator(DecelerateInterpolator()).start()
        } else if (p >= 100) {
            progress.animate().scaleX(1f).setDuration(d(160)).withEndAction {
                progress.animate().alpha(0f).setDuration(d(220)).withEndAction { progress.scaleX = 0f }.start()
            }.start()
        } else {
            progress.alpha = 0f
            progress.scaleX = 0f
        }
    }

    /** Back/Forward/Refresh now live in the three-dot menu (Chrome style) and read their state when it opens. */
    private fun updateNav() {}

    // =====================================================================
    // URL resolving + search
    // =====================================================================
    private fun looksLikeUrl(s: String): Boolean =
        !s.contains(' ') && (URL_RE.matches(s) || s.startsWith("about:"))

    private fun resolve(input: String): String {
        val s = input.trim()
        if (s.startsWith("http://") || s.startsWith("https://") || s.startsWith(ASSET)) return s
        if (looksLikeUrl(s)) {
            val local = s.startsWith("localhost") || Regex("^\\d{1,3}(\\.\\d{1,3}){3}.*").matches(s)
            return if (local) "http://$s" else "https://$s"
        }
        return searchUrl(s, false)
    }

    private fun engineName(): String {
        val k = stS("eng", "google")
        return when (k) {
            "custom" -> "custom engine"
            "ddg" -> "DuckDuckGo"
            else -> k.replaceFirstChar { it.uppercase() }
        }
    }

    private fun searchUrl(q: String, img: Boolean): String {
        val enc = URLEncoder.encode(q, "UTF-8")
        val key = stS("eng", "google")
        if (key == "custom" && !img) {
            val cu = stS("cust", "")
            if (cu.contains("%s")) return cu.replace("%s", enc)
        }
        val e = ENGINES[key] ?: ENGINES["google"]!!
        var u = (if (img) e.img else e.web) + enc
        if (key == "google" || !ENGINES.containsKey(key)) {
            if (stB("safe", false)) u += "&safe=active"
            val hl = stS("hl", "")
            if (hl.isNotEmpty()) u += "&hl=$hl"
        } else if (stB("safe", false)) {
            u += e.safe
        }
        return u
    }

    private fun scopeUrl(i: Int, q: String): String {
        val enc = URLEncoder.encode(q, "UTF-8")
        return when (i) {
            0 -> searchUrl(q, true)
            1 -> "https://www.youtube.com/results?search_query=$enc"
            2 -> "https://en.wikipedia.org/w/index.php?search=$enc"
            3 -> "https://github.com/search?q=$enc"
            4 -> "https://www.google.com/maps/search/$enc"
            else -> "https://www.amazon.com/s?k=$enc"
        }
    }

    private fun loadCurrent(url: String) {
        dropFocus()
        current?.let { loadWithMode(it, url) }
    }

    private fun navigateCurrent(input: String) {
        val s = input.trim()
        if (s.isEmpty()) return
        if (!looksLikeUrl(s) && !s.startsWith("http")) store.addRecent(s)
        loadCurrent(resolve(s))
    }

    private fun openInternal(page: String) {
        loadCurrent("$HOME#$page")
    }

    // =====================================================================
    // suggestions panel
    // =====================================================================
    private fun showSuggestPanel() {
        suggestPanel.animate().cancel()
        if (suggestPanel.visibility != View.VISIBLE) {
            suggestPanel.scrollTo(0, 0)
            suggestPanel.alpha = 0f
            suggestPanel.translationY = -dpf(12f)
            suggestPanel.visibility = View.VISIBLE
        }
        suggestPanel.animate().alpha(1f).translationY(0f).setDuration(d(200))
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun hideSuggestPanel() {
        suggestPanel.animate().cancel()
        if (suggestPanel.visibility == View.VISIBLE) {
            suggestPanel.animate().alpha(0f).translationY(-dpf(12f)).setDuration(d(150))
                .withEndAction { suggestPanel.visibility = View.GONE }.start()
        }
    }

    private fun animateIn(v: View, i: Int) {
        if (!animRows) return
        v.alpha = 0f
        v.translationY = dpf(10f)
        v.animate().alpha(1f).translationY(0f).setStartDelay(d(minOf(i, 8) * 24L)).setDuration(d(210))
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun addRow(v: View) {
        suggestList.addView(v)
        animateIn(v, rowIdx)
        rowIdx++
    }

    private fun suggestRow(icon: Int, tint: Int, title: String, sub: String?, fill: String, onClick: () -> Unit): View {
        val p = pal()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), 0, dp(4), 0)
        row.minimumHeight = dp(52)
        ripple(row)
        val ic = ImageView(this)
        ic.setImageResource(icon)
        ic.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
        row.addView(ic, LinearLayout.LayoutParams(dp(20), dp(20)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(8), dp(8), dp(8))
        val tv = TextView(this)
        tv.text = title
        tv.setTextColor(p.text)
        tv.textSize = 15f
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        col.addView(tv)
        if (sub != null) {
            val s = TextView(this)
            s.text = sub
            s.setTextColor(p.sub)
            s.textSize = 12f
            s.maxLines = 1
            s.ellipsize = TextUtils.TruncateAt.END
            col.addView(s)
        }
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val fb = ImageButton(this)
        fb.setImageResource(R.drawable.ic_fill)
        fb.setColorFilter(p.sub, PorterDuff.Mode.SRC_IN)
        fb.setBackgroundResource(0)
        fb.setPadding(dp(11), dp(11), dp(11), dp(11))
        fb.scaleType = ImageView.ScaleType.FIT_CENTER
        fb.contentDescription = "Use this suggestion"
        fb.setOnClickListener {
            setTextSilently(fill)
            urlInput.setSelection(urlInput.text.length)
            onUrlText(fill)
        }
        press(fb)
        row.addView(fb, LinearLayout.LayoutParams(dp(44), dp(44)))
        row.setOnClickListener { onClick() }
        return row
    }

    private fun chipsRow(q: String, p: Pal): View {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val ll = LinearLayout(this)
        ll.orientation = LinearLayout.HORIZONTAL
        ll.gravity = Gravity.CENTER_VERTICAL
        ll.setPadding(dp(14), dp(10), dp(8), dp(14))
        val label = TextView(this)
        label.text = "Search in"
        label.textSize = 12f
        label.setTextColor(p.sub)
        label.setPadding(0, 0, dp(10), 0)
        ll.addView(label)
        for (i in SCOPES.indices) {
            val chip = TextView(this)
            chip.text = SCOPES[i]
            chip.textSize = 13f
            chip.setTextColor(p.text)
            chip.gravity = Gravity.CENTER
            chip.setPadding(dp(14), dp(8), dp(14), dp(8))
            chip.background = rounded(p.pill, 18f)
            chip.setOnClickListener {
                store.addRecent(q)
                loadCurrent(scopeUrl(i, q))
            }
            press(chip)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(8)
            ll.addView(chip, lp)
        }
        hs.addView(ll)
        return hs
    }

    private fun buildSuggestions(q: String) {
        val p = pal()
        suggestList.removeAllViews()
        remoteHolder = null
        rowIdx = 0
        val text = q.trim()
        if (text.isEmpty()) {
            if (stB("recent", true)) {
                for (r in store.recents().take(6)) {
                    addRow(suggestRow(R.drawable.ic_history, p.sub, r, null, r) { navigateCurrent(r) })
                }
            }
            if (suggestList.childCount == 0) {
                val hint = TextView(this)
                hint.text = "Type a search or web address"
                hint.setTextColor(p.sub)
                hint.textSize = 14f
                hint.setPadding(dp(20), dp(20), dp(20), dp(20))
                addRow(hint)
            }
            return
        }
        val isUrl = looksLikeUrl(text)
        addRow(
            suggestRow(
                if (isUrl) R.drawable.ic_forward else R.drawable.ic_search, p.accent, text,
                if (isUrl) "Open web address" else "Search with " + engineName(), text
            ) { navigateCurrent(text) }
        )
        val cands = ArrayList<Triple<String, String, Boolean>>()
        val b = store.bookmarks()
        for (i in 0 until b.length()) {
            b.optJSONObject(i)?.let { cands.add(Triple(it.optString("t"), it.optString("u"), true)) }
        }
        val h = store.history()
        for (i in 0 until h.length()) {
            h.optJSONObject(i)?.let { cands.add(Triple(it.optString("q"), it.optString("u"), false)) }
        }
        val low = text.lowercase()
        val shown = HashSet<String>()
        for (cnd in cands) {
            if (shown.size >= 4) break
            if (cnd.second.isEmpty() || shown.contains(cnd.second)) continue
            if (cnd.first.lowercase().contains(low) || cnd.second.lowercase().contains(low)) {
                shown.add(cnd.second)
                val url = cnd.second
                addRow(
                    suggestRow(
                        if (cnd.third) R.drawable.ic_star else R.drawable.ic_history,
                        if (cnd.third) STAR else p.sub,
                        cnd.first.ifBlank { url }, displayUrl(url), url
                    ) { loadCurrent(url) }
                )
            }
        }
        val holder = LinearLayout(this)
        holder.orientation = LinearLayout.VERTICAL
        suggestList.addView(holder)
        remoteHolder = holder
        if (!isUrl) addRow(chipsRow(text, p))
    }

    private fun fillRemote(list: List<String>) {
        val h = remoteHolder ?: return
        val p = pal()
        val first = h.childCount == 0
        val typed = urlInput.text.toString().trim()
        h.removeAllViews()
        var i = 0
        for (s in list) {
            if (s.equals(typed, ignoreCase = true)) continue
            val v = suggestRow(R.drawable.ic_search, p.sub, s, null, s) { navigateCurrent(s) }
            h.addView(v)
            if (first) {
                v.alpha = 0f
                v.translationY = dpf(10f)
                v.animate().alpha(1f).translationY(0f).setStartDelay(d(i * 24L)).setDuration(d(210))
                    .setInterpolator(DecelerateInterpolator()).start()
            }
            i++
        }
    }

    private fun fetchRemote(q: String) {
        sugRunnable?.let { ui.removeCallbacks(it) }
        val text = q.trim()
        if (!stB("sugg", true) || text.length < 2) return
        val token = ++sugToken
        val r = Runnable {
            thread {
                val res: List<String> = try {
                    googleSuggest(text)
                } catch (e: Exception) {
                    emptyList()
                }
                runOnUiThread {
                    if (token == sugToken && urlInput.hasFocus() && res.isNotEmpty()) fillRemote(res)
                }
            }
        }
        sugRunnable = r
        ui.postDelayed(r, 220L)
    }

    private fun googleSuggest(q: String): List<String> {
        val hl = stS("hl", "")
        val url = "https://suggestqueries.google.com/complete/search?client=firefox&q=" +
            URLEncoder.encode(q, "UTF-8") + (if (hl.isNotEmpty()) "&hl=$hl" else "")
        val con = URL(url).openConnection() as HttpURLConnection
        try {
            con.connectTimeout = 3000
            con.readTimeout = 3000
            con.setRequestProperty("User-Agent", uaMobile)
            val txt = con.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(txt).getJSONArray(1)
            val out = ArrayList<String>()
            for (i in 0 until arr.length()) {
                if (out.size >= 6) break
                out.add(arr.getString(i))
            }
            return out
        } finally {
            con.disconnect()
        }
    }

    // =====================================================================
    // tabs
    // =====================================================================
    @Suppress("DEPRECATION")
    @SuppressLint("SetJavaScriptEnabled")
    private fun configure(t: Tab) {
        val w = t.web
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.mediaPlaybackRequiresUserGesture = true
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.textZoom = zoomPct()
        if (t.incognito) {
            s.cacheMode = WebSettings.LOAD_NO_CACHE
            s.saveFormData = false
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, !t.incognito)
        w.setBackgroundColor(pal().bg)
        w.addJavascriptInterface(Bridge(t), "NomanNative")
        w.webViewClient = Client(t)
        w.webChromeClient = Chrome(t)
        w.setDownloadListener { url, ua, cd, mime, _ -> startDownload(url, ua, cd, mime) }
        applyMode(t)
    }

    private fun applyMode(t: Tab) {
        val s = t.web.settings
        s.userAgentString = if (t.desktop) uaDesktop else uaMobile
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
    }

    private fun newTab(url: String?, incognito: Boolean = false, select: Boolean = true,
                       parent: Tab? = null, load: Boolean = true): Tab {
        val t = Tab(incognito)
        t.parent = parent
        configure(t)
        t.web.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        t.web.visibility = View.GONE
        content.addView(t.web, 0)
        tabs.add(t)
        updateTabCount()
        if (load) {
            t.trusted = url == null || url.startsWith(ASSET)
            loadWithMode(t, url ?: HOME)
        }
        if (select) switchTo(t, true)
        return t
    }

    private fun switchTo(t: Tab, animate: Boolean) {
        val old = current
        if (old != null && old !== t) {
            old.web.onPause()
            old.web.visibility = View.GONE
        }
        current = t
        dropFocus()
        t.web.visibility = View.VISIBLE
        t.web.onResume()
        t.web.alpha = 1f
        val wantSpin = t.loading && !t.trusted
        lastLoading = !wantSpin
        setLoading(wantSpin)
        progress.animate().cancel()
        progress.alpha = 0f
        progress.scaleX = 0f
        if (t.loading && !t.trusted) setProgress(t.progress)
        applyTheme(true)
        updateUrlUi()
        updateNav()
        if (t.trusted) t.web.evaluateJavascript("window.nomanRefresh&&nomanRefresh()", null)
    }

    private fun closeTab(t: Tab, next: Tab? = null) {
        val idx = tabs.indexOf(t)
        if (idx < 0) return
        val wasCurrent = t === current
        tabs.removeAt(idx)
        updateTabCount()
        t.web.stopLoading()
        if (t.incognito) {
            t.web.clearHistory()
            t.web.clearCache(true)
            t.web.clearFormData()
        }
        (t.web.parent as? ViewGroup)?.removeView(t.web)
        t.web.destroy()
        if (tabs.isEmpty()) {
            current = null
            newTab(null)
            return
        }
        if (wasCurrent) switchTo(next ?: tabs[minOf(idx, tabs.size - 1)], true)
    }

    private fun navBack(t: Tab): Boolean {
        if (t.web.canGoBack()) {
            t.web.goBack()
            return true
        }
        val par = t.parent
        if (par != null && tabs.contains(par)) {
            closeTab(t, par)
            return true
        }
        return false
    }

    private fun setupTabsOverlay() {
        press(btnNewTab)
        press(btnNewInc)
        btnNewTab.setOnClickListener { hideTabs(); newTab(null) }
        btnNewInc.setOnClickListener { hideTabs(); newTab(null, true) }
    }

    private fun updateTabsTitle() {
        val n = tabs.size
        tabsTitle.text = if (n == 1) "1 tab" else "$n tabs"
    }

    private fun toggleTabs() {
        if (tabsOpen) hideTabs() else showTabs()
    }

    private fun refreshTabsButton() {
        val p = pal()
        val violet = c("#8B5CF6")
        tabBg.setColor(if (tabsOpen) violet else Color.TRANSPARENT)
        tabBg.setStroke(dp(2), violet)
        tabCount.background = tabBg
        tabCount.setTextColor(if (tabsOpen) Color.WHITE else violet)
    }

    private fun updateTabCount() {
        val n = tabs.size
        tabCount.text = if (n > 99) ":D" else n.toString()
        if (n != lastCount) {
            lastCount = n
            tabCount.animate().cancel()
            tabCount.scaleX = 0.6f
            tabCount.scaleY = 0.6f
            tabCount.animate().scaleX(1f).scaleY(1f).setDuration(d(260))
                .setInterpolator(OvershootInterpolator(2.4f)).start()
        }
    }

    private fun showTabs() {
        dropFocus()
        tabsOpen = true
        refreshTabsButton()
        buildTabCards()
        tabsOverlay.animate().cancel()
        tabsOverlay.visibility = View.VISIBLE
        tabsOverlay.alpha = 0f
        tabsOverlay.scaleX = 0.96f
        tabsOverlay.scaleY = 0.96f
        tabsOverlay.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(d(220))
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun hideTabs() {
        tabsOpen = false
        refreshTabsButton()
        tabsOverlay.animate().cancel()
        tabsOverlay.animate().alpha(0f).scaleX(0.96f).scaleY(0.96f).setDuration(d(160))
            .withEndAction { tabsOverlay.visibility = View.GONE }.start()
    }

    private fun buildTabCards() {
        val p = pal()
        tabsList.removeAllViews()
        updateTabsTitle()
        for ((idx, tab) in tabs.withIndex()) {
            val isCur = tab === current
            val name = when {
                tab.trusted -> "NOMAN GO home"
                tab.title.isNotBlank() -> tab.title
                tab.url.isNotBlank() -> displayUrl(tab.url)
                else -> "New tab"
            }
            val sub = when {
                tab.incognito && tab.trusted -> "Incognito"
                tab.incognito -> "Incognito, " + displayUrl(tab.url)
                tab.trusted -> "Home"
                else -> displayUrl(tab.url)
            }
            val accent = if (tab.incognito) c("#9A73FF") else tabColor(tab.url + name)

            val card = LinearLayout(this)
            card.orientation = LinearLayout.HORIZONTAL
            card.gravity = Gravity.CENTER_VERTICAL
            card.setPadding(dp(12), dp(10), dp(6), dp(10))
            card.background = rounded(p.card, 18f, if (isCur) p.accent else p.line, if (isCur) 2 else 1)

            val badge = TextView(this)
            badge.text = name.take(1).uppercase()
            badge.gravity = Gravity.CENTER
            badge.setTextColor(Color.WHITE)
            badge.textSize = 16f
            badge.typeface = Typeface.DEFAULT_BOLD
            badge.background = circle(accent)
            card.addView(badge, LinearLayout.LayoutParams(dp(44), dp(44)))

            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dp(12), 0, dp(8), 0)
            val tt = TextView(this)
            tt.text = name
            tt.setTextColor(p.text)
            tt.textSize = 15f
            tt.typeface = Typeface.DEFAULT_BOLD
            tt.maxLines = 1
            tt.ellipsize = TextUtils.TruncateAt.END
            col.addView(tt)
            val su = TextView(this)
            su.text = sub
            su.setTextColor(p.sub)
            su.textSize = 12f
            su.maxLines = 1
            su.ellipsize = TextUtils.TruncateAt.END
            col.addView(su)
            card.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val close = ImageButton(this)
            close.setImageResource(R.drawable.ic_close)
            close.setColorFilter(p.sub, PorterDuff.Mode.SRC_IN)
            close.setBackgroundResource(0)
            close.setPadding(dp(11), dp(11), dp(11), dp(11))
            close.scaleType = ImageView.ScaleType.FIT_CENTER
            close.contentDescription = "Close tab"
            press(close)
            card.addView(close, LinearLayout.LayoutParams(dp(44), dp(44)))

            card.setOnClickListener {
                hideTabs()
                switchTo(tab, true)
            }
            close.setOnClickListener {
                card.animate().translationX(card.width.toFloat()).alpha(0f).setDuration(d(200)).withEndAction {
                    tabsList.removeView(card)
                    val wasLast = tabs.size == 1
                    closeTab(tab)
                    if (wasLast) hideTabs() else updateTabsTitle()
                }.start()
            }

            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72))
            lp.topMargin = dp(8)
            tabsList.addView(card, lp)
            card.alpha = 0f
            card.translationY = dpf(16f)
            card.animate().alpha(1f).translationY(0f).setStartDelay(d(minOf(idx, 6) * 30L)).setDuration(d(220))
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    // =====================================================================
    // home, voice search, toolbar animation
    // =====================================================================
    private fun goHome() {
        val t = current ?: return
        dropFocus()
        if (t.trusted && t.url == HOME) {
            t.web.evaluateJavascript("window.scrollTo({top:0,behavior:'smooth'})", null)
        } else {
            t.web.loadUrl(HOME)
        }
    }

    @Suppress("DEPRECATION")
    private fun applyRefreshRate() {
        try {
            val disp = windowManager.defaultDisplay
            var best = 60f
            if (!stB("eco", false)) {
                best = disp.refreshRate
                for (m in disp.supportedModes) if (m.refreshRate > best) best = m.refreshRate
            }
            if (best != lastRate) {
                lastRate = best
                val lp = window.attributes
                lp.preferredRefreshRate = best
                window.attributes = lp
            }
        } catch (e: Exception) {
        }
    }

    /** Optional: put Outfit-Bold.ttf in res/font/ as outfit_bold.ttf and the toolbar text uses it (matches the HTML). */
    private fun applyBrandFont() {
        if (Build.VERSION.SDK_INT < 26) return
        val id = resources.getIdentifier("outfit_bold", "font", packageName)
        if (id == 0) return
        try {
            val tf = resources.getFont(id)
            urlInput.typeface = tf
            tabCount.typeface = tf
            toastView.typeface = tf
        } catch (e: Exception) {
        }
    }

    private fun micAvailable(): Boolean = try {
        packageManager.queryIntentActivities(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0).isNotEmpty()
    } catch (e: Exception) {
        false
    }

    private fun applyMic() {
        btnMic.visibility = if (stB("mic", true) && micAvailable()) View.VISIBLE else View.GONE
    }

    private fun voiceLang(): String {
        val k = stS("vl", "").ifEmpty { stS("hl", "") }
        return when (k) {
            "bn" -> "bn-BD"
            "hi" -> "hi-IN"
            "ar" -> "ar-SA"
            "en" -> "en-US"
            else -> java.util.Locale.getDefault().toLanguageTag()
        }
    }

    private fun startVoice() {
        dropFocus()
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, voiceLang())
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to search")
        try {
            startActivityForResult(i, REQ_VOICE)
        } catch (e: Exception) {
            showToast("Voice search is not available on this device")
        }
    }

    private fun playToolbarIntro() {
        if (d(1L) == 0L) return
        val views = arrayOf<View>(btnHome, urlPill, btnMic, btnTabs, btnMenu)
        for ((n, v) in views.withIndex()) {
            if (v.visibility != View.VISIBLE) continue
            v.alpha = 0f
            v.translationY = -dpf(14f)
            v.scaleX = 0.7f
            v.scaleY = 0.7f
            v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay(d(80L + n * 55L)).setDuration(d(450))
                .setInterpolator(OvershootInterpolator(1.6f)).start()
        }
    }

    private fun bob(v: View) {
        v.animate().translationY(-dpf(3f)).scaleX(1.12f).scaleY(1.12f).setDuration(d(220)).withEndAction {
            v.animate().translationY(0f).scaleX(1f).scaleY(1f).setDuration(d(260))
                .setInterpolator(OvershootInterpolator(2f)).start()
        }.start()
    }

    private val idleTick = object : Runnable {
        override fun run() {
            if (d(1L) > 0L && menuPopup == null && tabsOverlay.visibility != View.VISIBLE && !urlInput.hasFocus()) {
                bob(btnHome)
                if (btnMic.visibility == View.VISIBLE) ui.postDelayed({ bob(btnMic) }, 700L)
            }
            ui.postDelayed(this, 4200L)
        }
    }

    private fun startIdle() {
        ui.removeCallbacks(idleTick)
        ui.postDelayed(idleTick, 3000L)
    }

    private fun stopIdle() {
        ui.removeCallbacks(idleTick)
    }

    // ---- menu icon animation: pop in, then a small loop that only runs while the menu is open
    private fun stopMenuAnims() {
        for (a in menuAnims) a.cancel()
        menuAnims.clear()
    }

    private fun animateMenuIcon(iv: ImageView, kind: String, order: Int) {
        if (d(1L) == 0L) return
        iv.scaleX = 0f
        iv.scaleY = 0f
        iv.rotation = -120f
        iv.animate().scaleX(1f).scaleY(1f).rotation(0f)
            .setStartDelay(d(120L + order * 45L)).setDuration(d(520))
            .setInterpolator(OvershootInterpolator(2.2f))
            .withEndAction { startIdleIcon(iv, kind) }.start()
    }

    private fun loopOf(a: ObjectAnimator, ms: Long, reverse: Boolean, delay: Long): ObjectAnimator {
        a.duration = ms
        a.startDelay = delay
        a.repeatCount = ValueAnimator.INFINITE
        if (reverse) a.repeatMode = ValueAnimator.REVERSE
        a.interpolator = if (reverse) AccelerateDecelerateInterpolator() else LinearInterpolator()
        return a
    }

    private fun startIdleIcon(iv: ImageView, kind: String) {
        if (menuPopup == null || d(1L) == 0L) return
        val a: ObjectAnimator = when (kind) {
            "gear" -> loopOf(ObjectAnimator.ofFloat(iv, View.ROTATION, 0f, 360f), 7000L, false, 0L)
            "plus" -> loopOf(ObjectAnimator.ofFloat(iv, View.ROTATION, 0f, 90f), 900L, true, 600L)
            "mask" -> loopOf(ObjectAnimator.ofFloat(iv, View.TRANSLATION_Y, 0f, -dpf(2.5f)), 1100L, true, 0L)
            "hist", "refresh" -> loopOf(ObjectAnimator.ofFloat(iv, View.ROTATION, 0f, 16f), 1000L, true, 0L)
            "star", "share" -> loopOf(
                ObjectAnimator.ofPropertyValuesHolder(
                    iv,
                    PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.18f),
                    PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.18f)
                ), 900L, true, 0L
            )
            "dl" -> loopOf(ObjectAnimator.ofFloat(iv, View.TRANSLATION_Y, 0f, dpf(3f)), 650L, true, 0L)
            "desk" -> loopOf(ObjectAnimator.ofFloat(iv, View.TRANSLATION_Y, 0f, -dpf(2.5f)), 1100L, true, 0L)
            "back" -> loopOf(ObjectAnimator.ofFloat(iv, View.TRANSLATION_X, 0f, -dpf(3f)), 700L, true, 0L)
            "fwd" -> loopOf(ObjectAnimator.ofFloat(iv, View.TRANSLATION_X, 0f, dpf(3f)), 700L, true, 0L)
            else -> return
        }
        a.start()
        menuAnims.add(a)
    }

    // =====================================================================
    // three-dot menu
    // =====================================================================
    private fun showMenu() {
        if (menuPopup?.isShowing == true) {
            dismissMenu(null)
            return
        }
        val t = current ?: return
        val p = pal()
        dropFocus()
        stopMenuAnims()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.background = rounded(p.card, 16f, p.line, 1)
        col.setPadding(dp(6), dp(8), dp(6), dp(8))
        col.elevation = dpf(10f)

        var i = 0
        val iconRow = LinearLayout(this)
        iconRow.orientation = LinearLayout.HORIZONTAL

        fun divider() {
            val v = View(this)
            v.setBackgroundColor(p.line)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
            lp.setMargins(dp(8), dp(4), dp(8), dp(4))
            col.addView(v, lp)
        }

        // Chrome style icon row: Back, Forward, (Bookmark on web pages), Refresh / Stop
        fun cell(icon: Int, tint: Int, label: String, enabled: Boolean, kind: String, onClick: () -> Unit) {
            val cv = LinearLayout(this)
            cv.orientation = LinearLayout.VERTICAL
            cv.gravity = Gravity.CENTER
            cv.setPadding(0, dp(8), 0, dp(6))
            if (enabled) ripple(cv)
            val iv = ImageView(this)
            iv.setImageResource(icon)
            iv.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
            cv.addView(iv, LinearLayout.LayoutParams(dp(24), dp(24)))
            val tv = TextView(this)
            tv.text = label
            tv.textSize = 10f
            tv.setTextColor(p.text)
            tv.gravity = Gravity.CENTER
            tv.setPadding(0, dp(3), 0, 0)
            cv.addView(tv)
            cv.alpha = if (enabled) 1f else 0.35f
            if (enabled) cv.setOnClickListener { dismissMenu(onClick) }
            iconRow.addView(cv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            animateMenuIcon(iv, kind, i)
            i++
        }

        fun row(icon: Int, tint: Int, label: String, kind: String, sw: Boolean? = null, onClick: () -> Unit) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(12), 0, dp(12), 0)
            ripple(r)
            val iv = ImageView(this)
            iv.setImageResource(icon)
            iv.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
            r.addView(iv, LinearLayout.LayoutParams(dp(22), dp(22)))
            val tv = TextView(this)
            tv.text = label
            tv.textSize = 15f
            tv.setTextColor(p.text)
            tv.setPadding(dp(14), 0, 0, 0)
            r.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val swv: CheckBox? = if (sw != null) {
                val s = CheckBox(this)
                s.isChecked = sw
                s.isClickable = false
                s.isFocusable = false
                s.buttonTintList = ColorStateList.valueOf(p.accent)
                r.addView(s)
                s
            } else {
                null
            }
            r.setOnClickListener {
                val s = swv
                if (s != null) {
                    s.isChecked = !s.isChecked
                    ui.postDelayed({ dismissMenu(onClick) }, 170L)
                } else {
                    dismissMenu(onClick)
                }
            }
            col.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
            animateMenuIcon(iv, kind, i)
            r.alpha = 0f
            r.translationY = -dpf(8f)
            r.animate().alpha(1f).translationY(0f).setStartDelay(d(40L + i * 22L)).setDuration(d(200))
                .setInterpolator(DecelerateInterpolator()).start()
            i++
        }

        val isWeb = !t.trusted && t.url.startsWith("http")
        val busy = t.loading && !t.trusted
        val canBack = t.web.canGoBack() || (t.parent?.let { tabs.contains(it) } == true)
        cell(R.drawable.ic_back, c("#64748B"), "Back", canBack, "back") { navBack(t) }
        cell(R.drawable.ic_forward, c("#64748B"), "Forward", t.web.canGoForward(), "fwd") { t.web.goForward() }
        if (isWeb) {
            val marked = store.isBookmarked(t.url)
            cell(
                if (marked) R.drawable.ic_star_fill else R.drawable.ic_star, STAR,
                if (marked) "Saved" else "Bookmark", true, "star"
            ) { toggleBookmark(t) }
        }
        cell(
            if (busy) R.drawable.ic_close else R.drawable.ic_refresh, c("#16A56A"),
            if (busy) "Stop" else "Refresh", true, "refresh"
        ) { if (busy) t.web.stopLoading() else t.web.reload() }
        col.addView(iconRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        divider()

        row(R.drawable.ic_plus, c("#4F8BFF"), "New tab", "plus") { newTab(null) }
        row(R.drawable.ic_mask, c("#8B5CF6"), "New incognito tab", "mask") { newTab(null, true) }
        if (isWeb) row(R.drawable.ic_share, c("#4F8BFF"), "Share", "share") { sharePage(t) }
        // Desktop site is in the menu on every screen: per site on web pages, for all sites on the home / internal pages
        val deskOn = if (t.trusted) stB("deskAll", false) else t.desktop
        row(
            R.drawable.ic_desktop, c("#FF7A2F"),
            if (t.trusted) "Desktop site (all sites)" else "Desktop site", "desk", deskOn
        ) { toggleDesktop(t) }
        divider()
        row(R.drawable.ic_star, STAR, "Bookmarks", "star") { openInternal("bookmarks") }
        row(R.drawable.ic_history, c("#64748B"), "History", "hist") { openInternal("history") }
        row(R.drawable.ic_download, c("#16A56A"), "Downloads", "dl") { openInternal("downloads") }
        row(R.drawable.ic_gear, c("#64748B"), "Settings", "gear") { openInternal("settings") }

        val wrap = FrameLayout(this)
        wrap.setPadding(dp(8), dp(2), dp(8), dp(16))
        wrap.addView(col, FrameLayout.LayoutParams(dp(262), ViewGroup.LayoutParams.WRAP_CONTENT))
        val pw = PopupWindow(wrap, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pw.isOutsideTouchable = true
        pw.setOnDismissListener {
            menuPopup = null
            stopMenuAnims()
            btnMenu.animate().rotation(0f).setDuration(d(200)).start()
        }
        menuPopup = pw
        wrap.pivotX = dpf(252f)
        wrap.pivotY = 0f
        wrap.alpha = 0f
        wrap.scaleX = 0.85f
        wrap.scaleY = 0.85f
        pw.showAsDropDown(btnMenu, 0, -dp(6), Gravity.END)
        wrap.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(d(220))
            .setInterpolator(OvershootInterpolator(1.1f)).start()
        btnMenu.animate().rotation(90f).setDuration(d(220)).start()
    }

    private fun dismissMenu(after: (() -> Unit)?) {
        val pw = menuPopup
        if (pw == null || !pw.isShowing) {
            after?.invoke()
            return
        }
        menuPopup = null
        stopMenuAnims()
        pw.contentView.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(d(130)).withEndAction {
            try {
                pw.dismiss()
            } catch (e: Exception) {
            }
            btnMenu.animate().rotation(0f).setDuration(d(200)).start()
            after?.invoke()
        }.start()
    }

    private fun toggleBookmark(t: Tab) {
        val on = store.toggleBookmark(t.title.ifBlank { t.url }, t.url)
        showToast(if (on) "Bookmark added" else "Bookmark removed")
    }

    private fun sharePage(t: Tab) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, t.url)
        i.putExtra(Intent.EXTRA_SUBJECT, t.title)
        startActivity(Intent.createChooser(i, "Share page"))
    }

    private fun hostOf(url: String): String? = try {
        Uri.parse(url).host?.removePrefix("www.")
    } catch (e: Exception) {
        null
    }

    /** Chrome style: a per-site choice wins, otherwise the global "Request desktop site" setting. */
    private fun effectiveDesktop(host: String?): Boolean {
        if (host == null) return false
        return store.deskOverride(host) ?: stB("deskAll", false)
    }

    private fun modeFor(t: Tab, host: String?): Boolean {
        if (t.incognito && host != null && t.manualHost == host) return t.desktop
        return effectiveDesktop(host)
    }

    /** Sets the right user-agent for the target site first, then loads it. */
    private fun loadWithMode(t: Tab, url: String) {
        if (!url.startsWith(ASSET)) {
            val want = modeFor(t, hostOf(url))
            if (want != t.desktop) {
                t.desktop = want
                applyMode(t)
            }
        }
        t.web.loadUrl(url)
    }

    private fun toggleGlobalDesktop() {
        val now = !stB("deskAll", false)
        val o = store.settings()
        o.put("deskAll", now)
        store.set(Store.K_ST, o.toString())
        st = o
        for (tb in tabs) {
            if (tb.trusted) {
                tb.web.evaluateJavascript("window.nomanRefresh&&nomanRefresh()", null)
            } else {
                val want = modeFor(tb, hostOf(tb.url))
                if (want != tb.desktop) {
                    tb.desktop = want
                    applyMode(tb)
                }
            }
        }
        showToast(if (now) "Desktop site on for all sites" else "Desktop site off for all sites")
    }

    private fun toggleDesktop(t: Tab) {
        if (t.trusted) {
            toggleGlobalDesktop()
            return
        }
        val host = hostOf(t.url)
        val now = !t.desktop
        if (host != null) {
            if (t.incognito) {
                t.manualHost = host
            } else {
                store.setDeskSite(host, if (now == stB("deskAll", false)) null else now)
            }
        }
        t.desktop = now
        applyMode(t)
        t.web.reload()
        showToast(if (now) "Desktop site on" else "Mobile site on")
    }

    // =====================================================================
    // back button
    // =====================================================================
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (menuPopup?.isShowing == true) {
            dismissMenu(null)
            return
        }
        if (customView != null) {
            exitFullscreen()
            return
        }
        if (tabsOverlay.visibility == View.VISIBLE) {
            hideTabs()
            return
        }
        if (urlInput.hasFocus()) {
            dropFocus()
            return
        }
        val t = current
        if (t == null) {
            super.onBackPressed()
            return
        }
        if (t.trusted) {
            // let the home page close its own popups / sub pages first
            t.web.evaluateJavascript("(function(){return !!(window.nomanBack&&window.nomanBack())})()") { r ->
                if (r != "true") backOrExit(t)
            }
            return
        }
        backOrExit(t)
    }

    private fun backOrExit(t: Tab) {
        if (navBack(t)) return
        if (!t.trusted) {
            t.web.loadUrl(HOME)
            return
        }
        if (tabs.size > 1) closeTab(t) else finish()
    }

    // =====================================================================
    // web clients
    // =====================================================================
    private fun handleUrl(uri: Uri): Boolean {
        val u = uri.toString()
        val scheme = uri.scheme ?: ""
        if (scheme == "http" || scheme == "https") return false
        if (u.startsWith(ASSET)) return false
        if (scheme == "about" || scheme == "data" || scheme == "blob" || scheme == "javascript") return false
        if (scheme == "file") return true
        try {
            val i = if (scheme == "intent") Intent.parseUri(u, Intent.URI_INTENT_SCHEME) else Intent(Intent.ACTION_VIEW, uri)
            i.addCategory(Intent.CATEGORY_BROWSABLE)
            i.component = null
            i.selector = null
            startActivity(i)
        } catch (e: Exception) {
            showToast("No app can open this link")
        }
        return true
    }

    private fun errorHtml(url: String, desc: String): String {
        val p = pal()
        fun hex(v: Int): String = String.format("#%06X", 0xFFFFFF and v)
        return "<html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><style>" +
            "body{margin:0;height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;" +
            "font-family:sans-serif;text-align:center;padding:24px;box-sizing:border-box;" +
            "background:" + hex(p.bg) + ";color:" + hex(p.text) + "}" +
            "h2{margin:0 0 8px}p{margin:0 0 22px;color:" + hex(p.sub) + "}" +
            "a{background:" + hex(p.accent) + ";color:#fff;padding:12px 26px;border-radius:99px;" +
            "text-decoration:none;font-weight:600}</style></head><body><h2>Can't reach this page</h2><p>" +
            esc(desc) + "</p><a href=\"" + esc(url) + "\">Try again</a></body></html>"
    }

    private inner class Client(private val t: Tab) : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val uri = request.url
            val scheme = uri.scheme ?: ""
            if (request.isForMainFrame && request.method == "GET" && (scheme == "http" || scheme == "https")) {
                val want = modeFor(t, hostOf(uri.toString()))
                if (want != t.desktop) {
                    // the next site wants a different mode: switch the user-agent, then load it again
                    t.desktop = want
                    applyMode(t)
                    view.loadUrl(uri.toString())
                    return true
                }
            }
            return handleUrl(uri)
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            t.url = url
            t.trusted = url.startsWith(ASSET)
            t.loading = true
            t.progress = 5
            if (t.errorPending) {
                t.errorPending = false
                t.errorShown = true
            } else {
                t.errorShown = false
            }
            view.settings.textZoom = if (t.trusted) 100 else zoomPct()
            if (t === current) {
                setLoading(!t.trusted)
                if (!t.trusted) setProgress(5)
                updateUrlUi()
                updateNav()
            }
        }

        override fun onPageCommitVisible(view: WebView, url: String) {
            if (t.desktop && !t.trusted) view.evaluateJavascript(DESKTOP_JS, null)
        }

        override fun onPageFinished(view: WebView, url: String) {
            t.loading = false
            t.progress = 100
            t.url = url
            t.title = view.title ?: ""
            if (t.desktop && !t.trusted) view.evaluateJavascript(DESKTOP_JS, null)
            if (!t.trusted && !t.errorShown && !t.incognito && url.startsWith("http")) {
                store.set(Store.K_LAST, url)
                if (stB("hist", true)) store.addHistory(t.title, url)
            }
            if (t === current) {
                setLoading(false)
                setProgress(100)
                updateUrlUi()
                updateNav()
            }
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (request.isForMainFrame) {
                t.errorPending = true
                val failing = request.url.toString()
                val why = error.description?.toString() ?: "Check your connection and try again."
                view.loadDataWithBaseURL(failing, errorHtml(failing, why), "text/html", "UTF-8", failing)
            }
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
            if (t === current) updateNav()
        }
    }

    private inner class Chrome(private val t: Tab) : WebChromeClient() {

        override fun onProgressChanged(view: WebView, newProgress: Int) {
            t.progress = newProgress
            if (t === current && !t.trusted && t.loading) setProgress(newProgress)
        }

        override fun onReceivedTitle(view: WebView, title: String?) {
            t.title = title ?: ""
        }

        override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
            if (!isUserGesture) return false
            val nt = newTab(null, t.incognito, true, t, false)
            nt.desktop = t.desktop
            applyMode(nt)
            val transport = resultMsg.obj as WebView.WebViewTransport
            transport.webView = nt.web
            resultMsg.sendToTarget()
            return true
        }

        override fun onCloseWindow(window: WebView) {
            ui.post { tabs.firstOrNull { it.web === window }?.let { closeTab(it) } }
        }

        override fun onShowFileChooser(
            webView: WebView,
            filePathCallback: ValueCallback<Array<Uri>>,
            fileChooserParams: WebChromeClient.FileChooserParams
        ): Boolean {
            fileCb?.onReceiveValue(null)
            fileCb = filePathCallback
            return try {
                startActivityForResult(fileChooserParams.createIntent(), REQ_FILE)
                true
            } catch (e: Exception) {
                fileCb = null
                false
            }
        }

        override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
            enterFullscreen(view, callback)
        }

        override fun onHideCustomView() {
            exitFullscreen()
        }
    }

    @Suppress("DEPRECATION")
    private fun enterFullscreen(v: View, cb: WebChromeClient.CustomViewCallback) {
        if (customView != null) {
            cb.onCustomViewHidden()
            return
        }
        customView = v
        customCb = cb
        (window.decorView as ViewGroup).addView(v, FrameLayout.LayoutParams(-1, -1))
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    @Suppress("DEPRECATION")
    private fun exitFullscreen() {
        val v = customView ?: return
        (window.decorView as ViewGroup).removeView(v)
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        setLightBars(!pal().dark)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_VOICE) {
            if (resultCode == RESULT_OK && data != null) {
                val r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                val txt = if (r != null && r.isNotEmpty()) r[0] else null
                if (txt != null) navigateCurrent(txt)
            }
            return
        }
        if (requestCode == REQ_FILE) {
            val r = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            fileCb?.onReceiveValue(r)
            fileCb = null
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    // =====================================================================
    // downloads
    // =====================================================================
    private fun startDownload(url: String, ua: String?, cd: String?, mime: String?) {
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            showToast("This download type is not supported")
            return
        }
        if (Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDl = arrayOf(url, ua ?: "", cd ?: "", mime ?: "")
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE)
            return
        }
        enqueueDownload(url, ua ?: "", cd ?: "", mime ?: "")
    }

    private fun enqueueDownload(url: String, ua: String, cd: String, mime: String) {
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req = DownloadManager.Request(Uri.parse(url))
            if (mime.isNotEmpty()) req.setMimeType(mime)
            if (ua.isNotEmpty()) req.addRequestHeader("User-Agent", ua)
            val ck = CookieManager.getInstance().getCookie(url)
            if (!ck.isNullOrEmpty()) req.addRequestHeader("Cookie", ck)
            req.setTitle(name)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val id = dm.enqueue(req)
            store.addDownload(id, name, url)
            showToast("Downloading $name")
        } catch (e: Exception) {
            showToast("Download could not start")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_STORAGE) {
            val p = pendingDl
            pendingDl = null
            if (p != null && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enqueueDownload(p[0], p[1], p[2], p[3])
            } else {
                showToast("Storage permission is needed to download files")
            }
        }
    }

    private fun downloadsJson(): String {
        val arr = store.downloads()
        val out = JSONArray()
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optLong("id")
            var status = "missing"
            var pct = 0
            var size = 0L
            val cur = dm.query(DownloadManager.Query().setFilterById(id))
            if (cur != null) {
                if (cur.moveToFirst()) {
                    val s = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    val total = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                    val soFar = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                    size = total
                    pct = if (total > 0) (soFar * 100 / total).toInt() else 0
                    status = when (s) {
                        DownloadManager.STATUS_SUCCESSFUL -> "done"
                        DownloadManager.STATUS_FAILED -> "failed"
                        DownloadManager.STATUS_PAUSED -> "paused"
                        DownloadManager.STATUS_PENDING -> "pending"
                        else -> "running"
                    }
                }
                cur.close()
            }
            if (status == "missing") continue
            out.put(
                JSONObject().put("id", id.toString()).put("n", o.optString("n")).put("u", o.optString("u"))
                    .put("t", o.optLong("t")).put("s", status).put("p", pct).put("z", size)
            )
        }
        return out.toString()
    }

    private fun openDownloadFile(id: Long) {
        try {
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val uri = dm.getUriForDownloadedFile(id)
            val mime = dm.getMimeTypeForDownloadedFile(id)
            if (uri == null) {
                showToast("The file is not ready yet")
                return
            }
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, mime)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            showToast("No app can open this file")
        }
    }

    // =====================================================================
    // JavaScript bridge used by assets/index.html (only for the bundled home page)
    // =====================================================================
    private inner class Bridge(private val t: Tab) {

        private fun ok(): Boolean = t.trusted

        @JavascriptInterface
        fun get(k: String): String? = if (ok() && Store.BRIDGE_KEYS.contains(k)) store.get(k) else null

        @JavascriptInterface
        fun set(k: String, v: String) {
            if (ok() && Store.BRIDGE_KEYS.contains(k)) store.set(k, v)
        }

        @JavascriptInterface
        fun clearAll() {
            if (!ok()) return
            store.clearAll()
            runOnUiThread { this@MainActivity.applySettings() }
        }

        @JavascriptInterface
        fun navigate(s: String) {
            if (!ok()) return
            runOnUiThread {
                if (tabs.contains(t)) {
                    dropFocus()
                    val q = s.trim()
                    if (q.isNotEmpty() && !looksLikeUrl(q) && !q.startsWith("http")) store.addRecent(q)
                    loadWithMode(t, resolve(q))
                }
            }
        }

        @JavascriptInterface
        fun newIncognito() {
            if (!ok()) return
            runOnUiThread { newTab(null, true) }
        }

        @JavascriptInterface
        fun closePage() {
            if (!ok()) return
            runOnUiThread {
                if (tabs.contains(t) && !navBack(t)) t.web.loadUrl(HOME)
            }
        }

        @JavascriptInterface
        fun applySettings() {
            if (!ok()) return
            runOnUiThread { this@MainActivity.applySettings() }
        }

        @JavascriptInterface
        fun deskSites(): String = if (ok()) store.deskSites().toString() else "{}"

        @JavascriptInterface
        fun setDeskSite(host: String, mode: String) {
            if (!ok()) return
            store.setDeskSite(host, when (mode) {
                "d" -> true
                "m" -> false
                else -> null
            })
        }

        @JavascriptInterface
        fun downloads(): String = if (ok()) downloadsJson() else "[]"

        @JavascriptInterface
        fun openDownload(id: String) {
            if (!ok()) return
            val n = id.toLongOrNull() ?: return
            runOnUiThread { openDownloadFile(n) }
        }

        @JavascriptInterface
        fun removeDownload(id: String) {
            if (!ok()) return
            val n = id.toLongOrNull() ?: return
            store.removeDownload(n)
        }

        @JavascriptInterface
        fun clearBrowsing(cookies: Boolean, cache: Boolean) {
            if (!ok()) return
            runOnUiThread {
                if (cookies) {
                    CookieManager.getInstance().removeAllCookies(null)
                    CookieManager.getInstance().flush()
                    WebStorage.getInstance().deleteAllData()
                }
                if (cache) {
                    for (tb in tabs) tb.web.clearCache(true)
                }
                showToast("Browsing data cleared")
            }
        }
    }
}
